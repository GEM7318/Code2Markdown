`code2markdown` is a simple solution to converting code files into renderable markdown.
