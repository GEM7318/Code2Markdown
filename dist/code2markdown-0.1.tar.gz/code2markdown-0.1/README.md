`code2markdown` is a simple solution for converting a variety of code files into renderable markdown.
