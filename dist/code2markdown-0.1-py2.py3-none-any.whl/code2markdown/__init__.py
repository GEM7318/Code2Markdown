"""
A simple converter for code to markdown.

CLI usage is:
cd dir/containing/code
code2markdown run

"""


__version__ = "0.1"

from .Code import Code
